
void tempo(unsigned char n) {
    
    volatile unsigned char j, k;
    unsigned char i;

    for (i = 0; i < n; i++) {
        for (j = 0; j < 41; j++) {
            for (k = 0; k < 3; k++);
        }
    }
}